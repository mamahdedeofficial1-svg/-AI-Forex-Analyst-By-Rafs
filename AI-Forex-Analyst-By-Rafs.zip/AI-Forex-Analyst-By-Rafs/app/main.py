import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="AI Forex Analyst By Rafs", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

FINNHUB_KEY = os.getenv("FINNHUB_API_KEY", "").strip()
TWELVE_KEY = os.getenv("TWELVEDATA_API_KEY", "").strip()

SYMBOLS = {
    "XAUUSD": {"twelve": "XAU/USD", "finnhub": "OANDA:XAU_USD", "label": "Gold / US Dollar"},
    "EURUSD": {"twelve": "EUR/USD", "finnhub": "OANDA:EUR_USD", "label": "Euro / US Dollar"},
    "GBPUSD": {"twelve": "GBP/USD", "finnhub": "OANDA:GBP_USD", "label": "British Pound / US Dollar"},
    "USDJPY": {"twelve": "USD/JPY", "finnhub": "OANDA:USD_JPY", "label": "US Dollar / Japanese Yen"},
}

@app.get("/")
async def home():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "service": "AI Forex Analyst By Rafs",
        "server_time": datetime.now(timezone.utc).isoformat(),
        "providers": {
            "twelvedata_configured": bool(TWELVE_KEY),
            "finnhub_configured": bool(FINNHUB_KEY),
            "ai_configured": bool(os.getenv("OPENAI_API_KEY", "").strip()),
        },
    }

async def get_twelve_series(symbol: str, interval: str = "1h", outputsize: int = 120):
    if not TWELVE_KEY:
        raise HTTPException(503, "Market data API belum dikonfigurasi. Tambahkan TWELVEDATA_API_KEY di hosting.")
    url = "https://api.twelvedata.com/time_series"
    params = {"symbol": symbol, "interval": interval, "outputsize": outputsize, "apikey": TWELVE_KEY}
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
    if data.get("status") == "error" or not data.get("values"):
        raise HTTPException(502, data.get("message", "Penyedia data tidak mengembalikan candle."))
    frame = pd.DataFrame(data["values"])
    for col in ["open", "high", "low", "close"]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=["close"]).iloc[::-1].reset_index(drop=True)
    return frame

def calculate_indicators(frame: pd.DataFrame) -> dict[str, Any]:
    close = frame["close"]
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, pd.NA)
    rsi = 100 - (100 / (1 + rs))
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal_line = macd.ewm(span=9, adjust=False).mean()
    latest = float(close.iloc[-1])
    e20, e50 = float(ema20.iloc[-1]), float(ema50.iloc[-1])
    rsi_value = float(rsi.iloc[-1]) if pd.notna(rsi.iloc[-1]) else 50.0
    macd_value = float(macd.iloc[-1])
    macd_signal = float(signal_line.iloc[-1])
    technical_points = 0
    technical_points += 1 if latest > e20 else -1
    technical_points += 1 if e20 > e50 else -1
    technical_points += 1 if macd_value > macd_signal else -1
    if rsi_value >= 55:
        technical_points += 1
    elif rsi_value <= 45:
        technical_points -= 1
    technical_points = max(-4, min(4, technical_points))
    technical_buy = round(50 + technical_points * 8.0)
    technical_buy = max(10, min(90, technical_buy))
    return {
        "last_price": latest,
        "ema20": e20,
        "ema50": e50,
        "rsi14": round(rsi_value, 2),
        "macd": round(macd_value, 6),
        "macd_signal": round(macd_signal, 6),
        "technical_buy": technical_buy,
        "technical_sell": 100 - technical_buy,
        "trend": "Bullish" if technical_points > 0 else "Bearish" if technical_points < 0 else "Neutral",
        "time": str(frame["datetime"].iloc[-1]) if "datetime" in frame.columns else None,
    }

@app.get("/api/market/{symbol}")
async def market(symbol: str, interval: str = "1h"):
    symbol = symbol.upper()
    if symbol not in SYMBOLS:
        raise HTTPException(404, "Pair belum didukung.")
    frame = await get_twelve_series(SYMBOLS[symbol]["twelve"], interval=interval)
    indicators = calculate_indicators(frame)
    return {
        "symbol": symbol,
        "label": SYMBOLS[symbol]["label"],
        "provider": "Twelve Data",
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "indicators": indicators,
        "candles": [
            {"time": str(row["datetime"]), "open": float(row["open"]), "high": float(row["high"]),
             "low": float(row["low"]), "close": float(row["close"])}
            for _, row in frame.tail(100).iterrows()
        ],
        "disclaimer": "Skor teknikal berbasis indikator sederhana; bukan probabilitas profit atau rekomendasi transaksi.",
    }

@app.get("/api/news")
async def news():
    if not FINNHUB_KEY:
        return {"configured": False, "provider": "Finnhub", "articles": [],
                "message": "Tambahkan FINNHUB_API_KEY di hosting untuk mengaktifkan berita."}
    url = "https://finnhub.io/api/v1/news"
    params = {"category": "forex", "token": FINNHUB_KEY}
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
    articles = [{
        "headline": item.get("headline", ""),
        "summary": item.get("summary", ""),
        "source": item.get("source", ""),
        "url": item.get("url", ""),
        "datetime": item.get("datetime"),
        "image": item.get("image", ""),
    } for item in data[:30]]
    return {"configured": True, "provider": "Finnhub", "articles": articles,
            "updated_at": datetime.now(timezone.utc).isoformat()}

@app.get("/api/calendar")
async def calendar():
    # Kalender resmi perlu feed/API berlisensi. Endpoint ini tidak mengarang jadwal.
    return {
        "configured": False,
        "events": [],
        "message": "Integrasi kalender ekonomi belum dikonfigurasi. Hubungkan penyedia kalender berlisensi agar jadwal, forecast, previous, dan actual akurat.",
    }

@app.post("/api/consult")
async def consult(payload: dict):
    question = str(payload.get("question", "")).strip()
    if not question:
        raise HTTPException(400, "Pertanyaan tidak boleh kosong.")
    if len(question) > 2000:
        raise HTTPException(400, "Pertanyaan maksimal 2.000 karakter.")
    # AI chat diaktifkan setelah endpoint model dan kebijakan data dipasang.
    if not os.getenv("OPENAI_API_KEY", "").strip():
        return {
            "configured": False,
            "answer": "AI Consultant belum aktif karena OPENAI_API_KEY belum dipasang di hosting. Dashboard tetap dapat menampilkan data pasar setelah API market-data dikonfigurasi.",
        }
    return {
        "configured": False,
        "answer": "Kunci AI terdeteksi, tetapi adapter model belum diaktifkan. Ini sengaja dibuat fail-closed agar website tidak mengklaim analisis AI yang belum benar-benar dijalankan.",
    }
