const $ = (id) => document.getElementById(id);
let chart, candleSeries;
function setClock(){ $("clock").textContent = new Date().toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"medium"}); }
setClock(); setInterval(setClock,1000);

async function api(path, options={}) {
  const response = await fetch(path, options);
  const data = await response.json().catch(()=>({detail:"Respons server tidak valid"}));
  if(!response.ok) throw new Error(data.detail || "Permintaan gagal");
  return data;
}
function initChart(){
  if(!window.LightweightCharts) return;
  const el=$("chart");
  chart=LightweightCharts.createChart(el,{width:el.clientWidth,height:290,layout:{background:{color:"#0c1422"},textColor:"#91a0b8"},grid:{vertLines:{color:"#172337"},horzLines:{color:"#172337"}},rightPriceScale:{borderColor:"#243149"},timeScale:{borderColor:"#243149",timeVisible:true},crosshair:{mode:1}});
  candleSeries=chart.addCandlestickSeries({upColor:"#39c995",downColor:"#ed727b",borderUpColor:"#39c995",borderDownColor:"#ed727b",wickUpColor:"#39c995",wickDownColor:"#ed727b"});
  new ResizeObserver(()=>chart.applyOptions({width:el.clientWidth})).observe(el);
}
async function loadMarket(symbol){
  $("pair").value=symbol; $("chart-name").textContent=symbol;
  $("signal-note").textContent="Mengambil candle dari penyedia data...";
  try{
    const data=await api(`/api/market/${symbol}?interval=1h`);
    const i=data.indicators;
    const candles=data.candles.map(c=>({time:Math.floor(new Date(c.time.replace(" ","T")+"Z").getTime()/1000),open:c.open,high:c.high,low:c.low,close:c.close})).filter(c=>Number.isFinite(c.time));
    if(candleSeries && candles.length) { candleSeries.setData(candles); chart.timeScale().fitContent(); }
    $("bias-label").textContent=i.trend;
    $("buy-score").textContent=i.technical_buy+"%"; $("sell-score").textContent=i.technical_sell+"%";
    $("buy-bar").style.width=i.technical_buy+"%"; $("sell-bar").style.width=i.technical_sell+"%";
    $("signal-note").textContent=`RSI ${i.rsi14}. Skor teknikal dihitung dari EMA20/50, RSI14, dan MACD. Bukan probabilitas profit.`;
    $("indicators").innerHTML=`<div><span>EMA 20</span><b>${i.ema20.toFixed(4)}</b></div><div><span>EMA 50</span><b>${i.ema50.toFixed(4)}</b></div><div><span>RSI 14</span><b>${i.rsi14}</b></div><div><span>MACD</span><b>${i.macd}</b></div>`;
    const id={XAUUSD:"xau",EURUSD:"eur",GBPUSD:"gbp",USDJPY:"jpy"}[symbol];
    if(id){$(id+"-price").textContent=i.last_price.toFixed(symbol==="USDJPY"?3: symbol==="XAUUSD"?2:5);$(id+"-status").textContent="Updated "+new Date(data.updated_at).toLocaleTimeString("id-ID");}
  }catch(e){$("signal-note").textContent=e.message; $("bias-label").textContent="Unavailable";}
}
async function loadNews(){
  try{
    const d=await api("/api/news");
    if(!d.configured){$("news-list").innerHTML=`<div class="notice">${d.message}</div>`;return;}
    $("news-list").innerHTML=d.articles.map(a=>`<article class="news-item"><div class="news-meta">${escapeHtml(a.source)} · ${a.datetime?new Date(a.datetime*1000).toLocaleString("id-ID"):"Waktu tidak tersedia"}</div><a href="${safeUrl(a.url)}" target="_blank" rel="noopener">${escapeHtml(a.headline)}</a><p>${escapeHtml(a.summary||"Tidak ada ringkasan.")}</p></article>`).join("")||'<p class="muted">Belum ada berita.</p>';
  }catch(e){$("news-list").textContent=e.message;}
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function safeUrl(s=""){try{const u=new URL(s);return ["https:","http:"].includes(u.protocol)?u.href:"#";}catch{return "#";}}
async function boot(){
  try{const h=await api("/api/health");$("connection").textContent=h.providers.twelvedata_configured?"Server online · Market API configured":"Server online · API setup needed";}
  catch{$("connection").textContent="Server unavailable";}
  initChart(); await Promise.all([loadMarket("XAUUSD"),loadNews()]);
  const cal=await api("/api/calendar").catch(e=>({message:e.message}));
  $("calendar-message").textContent=cal.message||"Kalender belum tersedia.";
}
$("refresh").addEventListener("click",()=>{loadMarket($("pair").value);loadNews();});
$("pair").addEventListener("change",e=>loadMarket(e.target.value));
document.querySelectorAll("[data-symbol]").forEach(b=>b.addEventListener("click",()=>{loadMarket(b.dataset.symbol);$("markets").scrollIntoView({behavior:"smooth"});}));
$("chat-form").addEventListener("submit",async e=>{
  e.preventDefault();const q=$("question").value.trim();if(!q)return;
  const log=$("chat-log");log.insertAdjacentHTML("beforeend",`<div class="chat-message user">${escapeHtml(q)}</div>`);$("question").value="";
  try{const r=await api("/api/consult",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:q})});log.insertAdjacentHTML("beforeend",`<div class="chat-message assistant">${escapeHtml(r.answer)}</div>`);}
  catch(err){log.insertAdjacentHTML("beforeend",`<div class="chat-message assistant">${escapeHtml(err.message)}</div>`);}
  log.scrollTop=log.scrollHeight;
});
boot();
