# AI Forex Analyst By Rafs

Website dashboard full-stack: FastAPI + HTML/CSS/JavaScript. Didesain agar bisa diedit melalui Acode dan dideploy dari GitHub ke Render tanpa Termux.

## Fitur yang sudah ada pada paket awal
- Dashboard responsif.
- Chart candlestick (TradingView Lightweight Charts).
- Pengambilan candle melalui Twelve Data.
- Perhitungan indikator EMA 20/50, RSI 14, MACD.
- Skor arah teknikal BUY/SELL (heuristik indikator; bukan probabilitas profit).
- Berita forex melalui Finnhub.
- Status integrasi kalender ekonomi dan AI yang jujur bila belum dikonfigurasi.

## Penting: API key
Aplikasi tidak dapat menampilkan data real-time tanpa API key penyedia data. Daftar akun dan buat API key pada penyedia masing-masing. Masukkan key hanya di Environment Variables pada Render:
- `TWELVEDATA_API_KEY`
- `FINNHUB_API_KEY`
- `OPENAI_API_KEY` (AI chat belum dihubungkan pada paket ini; jangan menganggapnya aktif hanya karena key tersedia).

Jangan pernah menaruh API key di `app/static/app.js`, HTML, atau repository publik.

## Deploy tanpa Termux
1. Ekstrak ZIP di HP.
2. Buat repository baru di GitHub melalui browser.
3. Upload isi folder proyek (bukan folder ZIP) ke repository.
4. Buat akun/login Render, pilih New > Web Service, lalu hubungkan repository GitHub.
5. Render membaca `render.yaml`. Pastikan Build Command `pip install -r requirements.txt` dan Start Command `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.
6. Di Render > Environment, isi API key yang diperlukan. Deploy.
7. Buka URL Render yang diberikan. Cek `/api/health`.

## Catatan data dan analisis
- Data pasar hanya tersedia bila API provider aktif dan paket API mengizinkan simbol/interval yang dipilih.
- Nama simbol XAU/USD dan pasangan forex dapat berbeda antarprovider; sesuaikan konfigurasi `SYMBOLS` di `app/main.py` jika provider menggunakan format lain.
- Finnhub forex news bergantung pada cakupan paket dan ketersediaan provider.
- Kalender ekonomi dan AI Consultant belum diaktifkan dalam paket ini. UI menampilkan status secara eksplisit, tidak membuat data palsu.
- Skor BUY/SELL saat ini adalah skor arah teknikal sederhana dari EMA/RSI/MACD. Belum menggabungkan fundamental, news impact, market structure, atau model AI.
- Ini alat edukasi/riset, bukan saran transaksi. Uji dengan data historis/paper trading dan jangan menganggap skor sebagai peluang profit.

## Struktur
```text
app/
  main.py
  static/
    index.html
    style.css
    app.js
requirements.txt
render.yaml
.env.example
```
